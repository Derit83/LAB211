package controller;

public class Run {
    public static void main(String[] args) {
        ContactMenu contactMenu = new ContactMenu();
        contactMenu.start();
    }
}