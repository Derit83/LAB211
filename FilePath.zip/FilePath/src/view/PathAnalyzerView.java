package view;

import model.PathAnalyzerModel;

public class PathAnalyzerView {
    private PathAnalyzerModel model;

    public PathAnalyzerView(PathAnalyzerModel model) {
        this.model = model;
    }

    public void analyzePath(String path) {
        model.analyzePath(path);

        String disk = model.getDisk();
        String[] folders = model.getFolders();
        String fileName = model.getFileName();
        String extension = model.getExtension();
        String folderPath = model.getFolderPath();

        if (disk != null && folders != null && fileName != null && extension != null && folderPath != null) {
            System.out.println("----- Result Analysis -----");
            System.out.println("Disk: " + disk);
            System.out.println("Extension: " + extension);
            System.out.println("File Name: " + fileName);
            System.out.println("Path: " + folderPath);
            System.out.print("Folders: ");
            for (String folder : folders) {
                System.out.print(folder + " ");
            }
            System.out.println();
        } else {
            System.out.println("Invalid file path!");
        }
    }
}