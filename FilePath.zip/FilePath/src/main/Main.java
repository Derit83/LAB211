package main;

import java.util.Scanner;

import model.PathAnalyzerModel;
import view.PathAnalyzerView;

public class Main {
    public static void main(String[] args) {
        PathAnalyzerModel model = new PathAnalyzerModel();
        PathAnalyzerView view = new PathAnalyzerView(model);

        Scanner scanner = new Scanner(System.in);
        System.out.print("Enter the file path(that already exist in your computer): ");
        String path = scanner.nextLine();
        scanner.close();

        view.analyzePath(path);
    }
}