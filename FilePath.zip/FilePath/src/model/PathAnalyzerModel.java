package model;

import java.io.File;

public class PathAnalyzerModel {
    public String disk;
    public String[] folders;
    public String fileName;
    public String extension;
    public String folderPath;

    public void analyzePath(String path) {
        File file = new File(path);

        if (file.exists()) {
            disk = getDisk(file);
            folders = getFolders(file);
            fileName = getFileName(file);
            extension = getExtension(file);
            folderPath = getPath(file);
        } else {
            disk = null;
            folders = null;
            fileName = null;
            extension = null;
            folderPath = null;
        }
    }

    public String getDisk(File file) {
        return file.getAbsolutePath().substring(0, 1);
    }

    public String[] getFolders(File file) {
        return file.getParent().split("\\\\");
    }

    public String getFileName(File file) {
        String fileName = file.getName();
        int dotIndex = fileName.lastIndexOf(".");
        if (dotIndex > 0) {
            return fileName.substring(0, dotIndex);
        }
        return fileName;
    }

    public String getExtension(File file) {
        String fileName = file.getName();
        int dotIndex = fileName.lastIndexOf(".");
        if (dotIndex > 0 && dotIndex < fileName.length() - 1) {
            return fileName.substring(dotIndex + 1);
        }
        return "";
    }

    public String getPath(File file) {
        return file.getParent();
    }

    public String getDisk() {
        return disk;
    }

    public String[] getFolders() {
        return folders;
    }

    public String getFileName() {
        return fileName;
    }

    public String getExtension() {
        return extension;
    }

    public String getFolderPath() {
        return folderPath;
    }
}