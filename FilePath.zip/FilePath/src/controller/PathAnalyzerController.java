package controller;

import model.PathAnalyzerModel;
import view.PathAnalyzerView;

public class PathAnalyzerController {
    private PathAnalyzerModel model;
    private PathAnalyzerView view;

    public PathAnalyzerController(PathAnalyzerModel model, PathAnalyzerView view) {
        this.model = model;
        this.view = view;
    }
}