package view;

import java.util.Map;

public class StringCounterView {
    public void displayWordCount(Map<String, Integer> wordCountMap) {
        System.out.print("{");
        boolean isFirstWord = true;
for (Map.Entry<String, Integer> entry : wordCountMap.entrySet()) {
            if (!isFirstWord) {
                System.out.print(", ");
            }
            System.out.print(entry.getKey() + " = " + entry.getValue());
            isFirstWord = false;
        }
        System.out.print("} ");
    }

    public void displayLetterCount(Map<Character, Integer> letterCountMap) {
        System.out.print("{");
        boolean isFirstLetter = true;
        for (Map.Entry<Character, Integer> entry : letterCountMap.entrySet()) {
            if (!isFirstLetter) {
                System.out.print(", ");
            }
            System.out.print(entry.getKey() + " = " + entry.getValue());
            isFirstLetter = false;
        }
        System.out.println("}");
    }
}