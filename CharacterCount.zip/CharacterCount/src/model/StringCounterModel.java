package model;

import java.util.HashMap;
import java.util.Map;
import java.util.StringTokenizer;

public class StringCounterModel {
    private Map<String, Integer> wordCountMap;
    private Map<Character, Integer> letterCountMap;

    public void countWordsAndLetters(String input) {
        wordCountMap = new HashMap<>();
        letterCountMap = new HashMap<>();

        StringTokenizer tokenizer = new StringTokenizer(input);
        while (tokenizer.hasMoreTokens()) {
            String token = tokenizer.nextToken().replaceAll("[^a-zA-Z_]", "");
            if (!token.isEmpty()) { // Only count non-empty words
                wordCountMap.put(token, wordCountMap.getOrDefault(token, 0) + 1);

                for (char c : token.toLowerCase().toCharArray()) {
                    if (Character.isLetter(c)) {
                        letterCountMap.put(c, letterCountMap.getOrDefault(c, 0) + 1);
                    }
                }
            }
        }
    }

    public Map<String, Integer> getWordCountMap() {
        return wordCountMap;
    }

    public Map<Character, Integer> getLetterCountMap() {
        return letterCountMap;
    }
}