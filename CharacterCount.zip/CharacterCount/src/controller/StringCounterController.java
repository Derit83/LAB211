package controller;

import java.util.Scanner;
import model.StringCounterModel;
import view.StringCounterView;

public class StringCounterController {
    private StringCounterView view;
    private StringCounterModel model;

    public StringCounterController() {
        this.view = new StringCounterView();
        this.model = new StringCounterModel();
    }

    public void run() {
        Scanner scanner = new Scanner(System.in);
        System.out.print("Enter your content: ");
        String input = scanner.nextLine().trim();

        if (input.isEmpty()) {
            System.out.println("Input cannot be empty.");
            return;
        }

        model.countWordsAndLetters(input);

        view.displayWordCount(model.getWordCountMap());
        view.displayLetterCount(model.getLetterCountMap());
    }

    public static void main(String[] args) {
        StringCounterController controller = new StringCounterController();
        controller.run();
    }
}