package Main;

import controller.EbankController;
import model.EbankModel;
import view.EbankView;
public class Main {
    public static void main(String[] args) {
    EbankView view = new EbankView();
    EbankModel model = new EbankModel("En");
    EbankController controller = new EbankController(model, view);
    controller.start();
}
}