package controller;

import model.EbankModel;
import view.EbankView;

public class EbankController {
private EbankModel model;
private EbankView view;
private String currentCaptcha;  

    public EbankController(EbankModel model, EbankView view) {
    this.model = model;
    this.view = view;
}

public void start() {
    int option = view.getLanguageOption();

    switch (option) {
        case 1:
            model = new EbankModel("vi");
            login();
            break;
        case 2:
            model = new EbankModel("en");
            login();
            break;
        case 3:
            System.exit(0);
        default:
            view.displayMessage(model.getResourceString("invalid_option"));
            start();
    }
}

private void login() {
    String accountNumber = view.getAccountNumber();

    while (!model.isValidAccountNumber(accountNumber)) {
        view.displayMessage(model.getResourceString("invalid_account_number"));
        accountNumber = view.getAccountNumber();
    }

    String password = view.getPassword();

    while (!model.isValidPassword(password)) {
        view.displayMessage(model.getResourceString("invalid_password"));
        password = view.getPassword();
    }

    String captcha = model.getRandomCaptcha();
    view.displayMessage("Captcha: " + captcha);
    String captchaInput = view.getCaptchaInput(captcha);

    while (!captchaInput.equalsIgnoreCase(captcha)) {
    view.displayMessage(model.getResourceString("incorrect_captcha"));
    captcha = model.getRandomCaptcha();
    view.displayMessage("Captcha: " + captcha);
    captchaInput = view.getCaptchaInput(captcha);
    currentCaptcha = captcha; // Thay đổi này để gán lại giá trị cho biến currentCaptcha
}

    view.displayMessage(model.getResourceString("login_successful"));
}
}