package view;

import java.util.Scanner;

public class EbankView {
private Scanner scanner;


  public EbankView() {
    scanner = new Scanner(System.in);
}

public int getLanguageOption() {
System.out.println("-------Login Program-------");
System.out.println("1. Vietnamese");
System.out.println("2. English");
System.out.println("3. Exit");
System.out.print("Please choose an option: ");
int option = scanner.nextInt();
scanner.nextLine(); // Đọc dòng trống còn lại
return option;
}

    public String getAccountNumber() {
System.out.print("Account number: ");
return scanner.nextLine();
    }

    public String getPassword() {
System.out.print("Password: ");
return scanner.nextLine();
}
    

public String getCaptchaInput(String captcha) {
    String captchaInput;
    while (true) {
        System.out.print("Enter the captcha: ");
        captchaInput = scanner.nextLine();
        if (captchaInput.length() == 1 && isValidCaptcha(captchaInput, captcha)) {
            break;
        } else {
            System.out.println("Captcha incorrect");
        }
    }
    return captchaInput;
}

private boolean isValidCaptcha(String captchaInput, String captcha) {
    for (char c : captcha.toCharArray()) {
        if (c == captchaInput.charAt(0)) {
            return true;
        }
    }
    return false;
}
public void displayMessage(String message) {
    System.out.println(message);
}
}