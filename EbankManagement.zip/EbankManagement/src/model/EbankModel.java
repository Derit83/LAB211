package model;

import java.util.Random;
import java.util.ResourceBundle;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class EbankModel {
    private static final String ACCOUNT_NUMBER_REGEX = "\\d{10}";
    private static final String PASSWORD_REGEX = "^(?=.*[A-Za-z])(?=.*\\d)[A-Za-z\\d]{8,31}$";
    private ResourceBundle resourceBundle;
private Random random;
   public EbankModel(String locale) {
    resourceBundle = ResourceBundle.getBundle("resources." + locale.toLowerCase());
    random = new Random();
}

public boolean isValidAccountNumber(String accountNumber) {
return accountNumber.matches("\\d{10}");
}

    public boolean isValidPassword(String password) {
    Pattern pattern = Pattern.compile(PASSWORD_REGEX);
    Matcher matcher = pattern.matcher(password);
    return matcher.matches();
}

public String getRandomCaptcha() {
    
    return generateCaptcha();
}
private String generateCaptcha() {
String characters = "ABCDEFGHIJKLMNOPQRSTUVWXYZ1234567890";
StringBuilder captchaBuilder = new StringBuilder();
for (int i = 0; i < 5; i++) {
int index = random.nextInt(characters.length());
captchaBuilder.append(characters.charAt(index));
}
return captchaBuilder.toString();
}

    public String getResourceString(String key) {
    return resourceBundle.getString(key);
}
}