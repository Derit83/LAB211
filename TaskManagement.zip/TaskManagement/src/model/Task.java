package model;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Scanner;

public class Task {
    public static int lastTaskID = 0;
    public int id;
    public int taskTypeID;
    public String requirementName;
    public Date date;
    public double planFrom;
    public double planTo;
    public String assignee;
    public String reviewer;
    
    public Task(int taskTypeID, String requirementName, Date date, double planFrom, double planTo, String assignee, String reviewer) {
        this.id = ++lastTaskID;
        this.taskTypeID = taskTypeID;
        this.requirementName = requirementName;
        this.date = date;
        this.planFrom = planFrom;
        this.planTo = planTo;
        this.assignee = assignee;
        this.reviewer = reviewer;
    }
    
    public int getId() {
        return id;
    }
    
    public int getTaskTypeID() {
        return taskTypeID;
    }
    
    public String getRequirementName() {
        return requirementName;
    }
    
    public Date getDate() {
        return date;
    }
    
    public double getPlanFrom() {
        return planFrom;
    }
    
    public double getPlanTo() {
        return planTo;
    }
    
    public String getAssignee() {
        return assignee;
    }
    
    public String getReviewer() {
        return reviewer;
    }
}

