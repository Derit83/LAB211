package view;

import java.util.Date;

public class TaskData {
    public int taskTypeID;
    public String requirementName;
    public Date date;
    public double planFrom;
    public double planTo;
    public String assignee;
}