package view;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.Scanner;
import model.Task;

public class TaskView {
    public void displayMenu() {
        System.out.println("========= Task program =========");
        System.out.println("1. Add Task");
        System.out.println("2. Delete Task");
        System.out.println("3. Display Task");
        System.out.println("4. Exit");
    }
    
    public TaskData getTaskInput() {
        Scanner scanner = new Scanner(System.in);
        TaskData taskData = new TaskData();
        
        System.out.println("------------Add Task---------------");
        System.out.print("Requirement Name: ");
        taskData.requirementName = scanner.nextLine();
        
        System.out.print("Task Type: ");
        taskData.taskTypeID = Integer.parseInt(scanner.nextLine());
        
        System.out.print("Date (dd-MM-yyyy): ");
        taskData.date = parseDate(scanner.nextLine());
        
        System.out.print("From: ");
        taskData.planFrom = Double.parseDouble(scanner.nextLine());
        
        System.out.print("To: ");
        taskData.planTo = Double.parseDouble(scanner.nextLine());
        
        System.out.print("Assignee: ");
        taskData.assignee = scanner.nextLine();
        
        return taskData;
    }
    
    public String getTaskIdInput() {
        Scanner scanner = new Scanner(System.in);
        
        System.out.println("---------Del Task------");
        System.out.print("ID: ");
        return scanner.nextLine();
    }
    
    public void displayTasks(List<Task> tasks) {
    System.out.println("----------------------------------------- Task ---------------------------------------");
    System.out.println("ID\tName\t\t\tTask Type\tDate\t\t\tTime\t\tAssignee\t\tReviewer");

    for (Task task : tasks) {
        double time = task.getPlanTo() - task.getPlanFrom();
        System.out.printf("%d\t%-20s\t%-12s\t%s\t\t%.1f\t\t%-15s\t%s\n",
                task.getId(),
                task.getRequirementName(),
                getTaskTypeName(task.getTaskTypeID()),
                formatDate(task.getDate()),
                time,
                task.getAssignee(),
                task.getReviewer());
    }
}
    
    private String formatDate(Date date) {
        SimpleDateFormat dateFormat = new SimpleDateFormat("dd-MM-yyyy");
        return dateFormat.format(date);
    }
    
    private String getTaskTypeName(int taskTypeID) {
        switch (taskTypeID) {
            case 1:
                return "Code";
            case 2:
                return "Test";
            case 3:
                return "Design";
            case 4:
                return "Review";
            default:
                return "Unknown";
        }
    }
    
    private Date parseDate(String dateString) {
        SimpleDateFormat dateFormat = new SimpleDateFormat("dd-MM-yyyy");
        try {
            return dateFormat.parse(dateString);
        } catch (Exception e) {
            return null;
        }
    }
}