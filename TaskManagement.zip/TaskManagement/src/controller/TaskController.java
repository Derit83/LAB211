package controller;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Scanner;
import model.Task;
import model.TaskType;
import view.TaskView;

public class TaskController {
    public TaskView view;
    public List<Task> tasks;
    public List<TaskType> taskTypes;

    public TaskController() {
        view = new TaskView();
        tasks = new ArrayList<>();
        taskTypes = new ArrayList<>();

        // Initialize task types
        taskTypes.add(new TaskType(1, "Code"));
        taskTypes.add(new TaskType(2, "Test"));
        taskTypes.add(new TaskType(3, "Design"));
        taskTypes.add(new TaskType(4, "Review"));
    }

    public void start() {
        int option;
        do {
            view.displayMenu();
            option = getUserOption();
            performAction(option);
        } while (option != 4);
    }

    private int getUserOption() {
        Scanner scanner = new Scanner(System.in);
        System.out.print("Enter your option: ");
        return Integer.parseInt(scanner.nextLine());
    }

    private void performAction(int option) {
        switch (option) {
            case 1:
                addTask();
                break;
            case 2:
                deleteTask();
                break;
            case 3:
                displayTasks();
                break;
            case 4:
                System.out.println("Exiting the program...");
                break;
            default:
                System.out.println("Invalid option. Please try again.");
                break;
        }
    }

    private void addTask() {
        view.TaskData taskData = view.getTaskInput();

    try {
        System.out.print("Reviewer: ");
        String reviewer = new Scanner(System.in).nextLine();

        double time = taskData.planTo - taskData.planFrom;

        Task task = new Task(
                taskData.taskTypeID,
                taskData.requirementName,
                taskData.date,
                taskData.planFrom,
                taskData.planTo,
                taskData.assignee,
                reviewer
        );
        tasks.add(task);
        System.out.println("Task added successfully.");
    } catch (Exception e) {
        System.out.println("Error: " + e.getMessage());
    }
}

    private void deleteTask() {
        String taskId = view.getTaskIdInput();

        try {
            Task taskToDelete = null;
            for (Task task : tasks) {
                if (String.valueOf(task.getId()).equals(taskId)) {
                    taskToDelete = task;
                    break;
                }
            }

            if (taskToDelete != null) {
                tasks.remove(taskToDelete);
                System.out.println("Task deleted successfully.");
            } else {
                System.out.println("Task not found.");
            }
        } catch (Exception e) {
            System.out.println("Error: " + e.getMessage());
        }
    }

    private void displayTasks() {
        view.displayTasks(tasks);
    }

    private static class TaskData {
        public int taskTypeID;
        public String requirementName;
        public Date date;
        public double planFrom;
        public double planTo;
        public String assignee;
    }
}