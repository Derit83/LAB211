    package Controller;

    import Model.Student;
    import View.StudentView;

    import java.util.ArrayList;
    import java.util.Collections;
    import java.util.Comparator;
    import java.util.Iterator;
    import java.util.List;

    public class StudentController {
        private List<Student> students;
        private StudentView studentView;

        public StudentController() {
            students = new ArrayList<>();
            studentView = new StudentView();
        }

        public void createStudent(String id, String name, int semester, String course) {
            Student student = new Student(id, name, semester, course);
            students.add(student);
        }

        public List<Student> findStudentsByName(String searchName) {
            List<Student> foundStudents = new ArrayList<>();
            for (Student student : students) {
                if (student.getName().toLowerCase().contains(searchName.toLowerCase())) {
                    foundStudents.add(student);
                }
            }
            return foundStudents;
        }
       public List<Student> sortStudentsByName() {
        List<Student> sortedStudents = new ArrayList<>(students);
        Collections.sort(sortedStudents, new Comparator<Student>() {
            @Override
            public int compare(Student student1, Student student2) {
                return student1.getName().compareToIgnoreCase(student2.getName());
            }
        });
        return sortedStudents;
    }

    public void updateStudentName(String id, String newName) {
            for (Student student : students) {
                if (student.getId().equals(id)) {
                    student.setName(newName);
                    System.out.println("Student name updated successfully.");
                    return;
                }
            }
            System.out.println("No student found with ID: " + id);
        }

        public void deleteStudent(Student id) {
            Iterator<Student> iterator = students.iterator();
            while (iterator.hasNext()) {
                Student student = iterator.next();
                if (student.getId().equals(id)) {
                    iterator.remove();
                    System.out.println("Student deleted successfully.");
                    return;
                }
            }
            System.out.println("No student found with ID: " + id);
        }

        public List<String> generateReport() {
            List<String> report = new ArrayList<>();
            List<String> processedStudents = new ArrayList<>();

            for (Student student : students) {
                String studentKey = student.getName() + "|" + student.getCourse();
                if (!processedStudents.contains(studentKey)) {
                    int totalCourses = Collections.frequency(students, student);
                    String line = student.getName() + "\t" + student.getCourse() + "\t" + totalCourses;
                    report.add(line);
                    processedStudents.add(studentKey);
                }
            }

            return report;
        }

        public void printStudentDetails(Student student) {
            studentView.printStudentDetails(student);
        }

        public void printStudentList(List<Student> students) {
            studentView.printStudentList(students);
        }

        public void printReport(List<String> report) {
            studentView.printReport(report);
        }

   public Student findStudentById(String id) {
    for (Student student : students) {
        if (student.getId().equals(id)) {
            return student;
        }
    }
    return null;
}
    }