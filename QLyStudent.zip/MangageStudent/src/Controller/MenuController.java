package Controller;
import Model.Student;
import java.util.List;
import java.util.Scanner;

public class MenuController {
    private StudentController studentController;

    public MenuController() {
        studentController = new StudentController();
    }

    public void displayMenu() {
        Scanner scanner = new Scanner(System.in);
        int choice = 0;

        while (choice != 5) {
        System.out.println("===== Student Management Menu =====");
        System.out.println("1. Create Student");
        System.out.println("2. Sort/Find Students by Name");
        System.out.println("3. Update/Delete");
        System.out.println("4. Generate Report");
        System.out.println("5. Exit");
        System.out.print("Enter your choice: ");
        choice = scanner.nextInt();
        scanner.nextLine();

        switch (choice) {
            case 1:
                createStudent();
                break;
            case 2:
                findStudentsByName();
                break;
            case 3:
                updateOrDeleteStudent();
                break;
            case 4:
                generateReport();
                break;
            case 5:
                System.out.println("Exiting...");
                break;
            default:
                System.out.println("Invalid choice. Please try again.");
                break;
        }
    }
}
    private void createStudent() {
        Scanner scanner = new Scanner(System.in);
        System.out.print("Enter student ID: ");
        String id = scanner.nextLine();
        System.out.print("Enter student name: ");
        String name = scanner.nextLine();
        System.out.print("Enter semester: ");
        int semester = scanner.nextInt();
        scanner.nextLine();
        System.out.print("Enter course: ");
        String course = scanner.nextLine();

        studentController.createStudent(id, name, semester, course);
        System.out.println("Student created successfully.");
    }

   private void findStudentsByName() {
    Scanner scanner = new Scanner(System.in);
    System.out.print("Enter student name: ");
    String name = scanner.nextLine();

    studentController.sortStudentsByName(); 

    List<Student> foundStudents = studentController.findStudentsByName(name);
    if (foundStudents.isEmpty()) {
        System.out.println("No students found with name: " + name);
    } else {
        System.out.println("Students found with name " + name + ":");
        studentController.printStudentList(foundStudents);
    }
}
private void updateOrDeleteStudent() {
    Scanner scanner = new Scanner(System.in);
    System.out.print("Enter student ID: ");
    String id = scanner.nextLine();

    System.out.println("Searching for student with ID: " + id);
    Student foundStudent = studentController.findStudentById(id);
    if (foundStudent == null) {
        System.out.println("No student found with ID: " + id);
        return;
    }

    System.out.print("Do you want to update (U) or delete (D) the student? Enter your choice: ");
    String choice = scanner.nextLine();
    if (choice.equalsIgnoreCase("U")) {
        updateStudent(foundStudent);
    } else if (choice.equalsIgnoreCase("D")) {
        deleteStudent(foundStudent);
    } else {
        System.out.println("Invalid choice. Please try again.");
    }
}

  private void updateStudent(Student student) {
    Scanner scanner = new Scanner(System.in);
    System.out.print("Enter new name: ");
    String newName = scanner.nextLine();
    System.out.print("Enter new semester: ");
    int newSemester = scanner.nextInt();
    scanner.nextLine();
    System.out.print("Enter new course: ");
    String newCourse = scanner.nextLine();

    student.setName(newName);
    student.setSemester(newSemester); 
    student.setCourse(newCourse);
    System.out.println("Student updated successfully.");
}

    private void deleteStudent(Student student) {
        studentController.deleteStudent(student);
        System.out.println("Student deleted successfully.");
    }

    private void generateReport() {
        studentController.printReport(studentController.generateReport());
    }
}
    