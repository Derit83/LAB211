package Model;
import Controller.MenuController;

public class Main {
    public static void main(String[] args) {
        MenuController menuController = new MenuController();
        menuController.displayMenu();
    }
}