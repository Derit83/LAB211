
package main;
import controller.ShopController;
import view.ShopView;
public class ShopMain {
    public static void main(String[] args) {
        ShopController controller = new ShopController();
        controller.start();
    }
}
