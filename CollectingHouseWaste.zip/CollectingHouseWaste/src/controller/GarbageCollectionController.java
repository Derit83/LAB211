package controller;

import model.GarbageCollectionModel;
import model.GarbageStation;
import view.GarbageCollectionView;

public class GarbageCollectionController {
    private GarbageCollectionModel model;
    private GarbageCollectionView view;

    public GarbageCollectionController(GarbageCollectionModel model, GarbageCollectionView view) {
        this.model = model;
        this.view = view;
    }

    public void estimateCost() {
    int[] garbageAmounts = view.readGarbageAmountsFromUser();
    model.setGarbageAtStations(garbageAmounts);
    int totalCost = model.calculateCost();
    view.displayTotalCost(totalCost);
}
}