package main;

import controller.GarbageCollectionController;
import model.GarbageCollectionModel;
import view.GarbageCollectionView;

public class GarbageCollectionApp {
    public static void main(String[] args) {
        GarbageCollectionView view = new GarbageCollectionView();
        GarbageCollectionModel model = new GarbageCollectionModel();
        GarbageCollectionController controller = new GarbageCollectionController(model, view);
        controller.estimateCost();
    }
}