package view;

import model.GarbageStation;

import java.util.Scanner;

public class GarbageCollectionView {
    private Scanner scanner;

    public GarbageCollectionView() {
        scanner = new Scanner(System.in);
    }

    public int[] readGarbageAmountsFromUser() {
    System.out.print("Enter the number of garbage stations: ");
    int numStations = scanner.nextInt();

    int[] garbageAmounts = new int[numStations];

    for (int i = 0; i < numStations; i++) {
        System.out.print("Enter garbage amount at station " + (i + 1) + ": ");
        int garbageAmount = scanner.nextInt();

        garbageAmounts[i] = garbageAmount;
    }

    return garbageAmounts;
}

    public void displayTotalCost(int totalCost) {
        System.out.println("Total cost: " + totalCost);
    }
}