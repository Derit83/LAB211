package model;

public class GarbageCollectionModel {
    private final int TIME_TO_LOAD_GARBAGE = 8;    // Time to load garbage at each station in minutes
    private final int TIME_TO_DUMP = 30;           // Time to go to and from the dump in minutes
    private final int LABOR_COST_PER_HOUR = 120000; // Labor cost per hour in VND
    private final int DUMP_COST_PER_TRUCK = 57000;  // Cost paid for the dump per truck in VND

    private int[] garbageAtStations;
    private int totalCost;

    public void setGarbageAtStations(int[] garbageAtStations) {
        this.garbageAtStations = garbageAtStations;
    }

    public int calculateCost() {
        int total = 0;
        int time = 0;
        int count = 0;
        int maxTruckCapacity = 10000;

        for (int i = 0; i < garbageAtStations.length; i++) {
            total += garbageAtStations[i];
            time += TIME_TO_LOAD_GARBAGE;

            if (total > maxTruckCapacity) {
                total = 0;
                i--;
                time += TIME_TO_DUMP - TIME_TO_LOAD_GARBAGE;
                count++;
            } else if (i == garbageAtStations.length - 1) {
                time += TIME_TO_DUMP;
            }
        }
        count++;
        this.totalCost = (time * LABOR_COST_PER_HOUR / 60) + (DUMP_COST_PER_TRUCK * count);
        return totalCost;
    }

    public int getTotalCost() {
        return totalCost;
    }
}