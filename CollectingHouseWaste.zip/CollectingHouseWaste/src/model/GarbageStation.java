package model;

public class GarbageStation {
    public int garbageAmount;

    public GarbageStation(int garbageAmount) {
        this.garbageAmount = garbageAmount;
    }

    public int getGarbageAmount() {
        return garbageAmount;
    }
}