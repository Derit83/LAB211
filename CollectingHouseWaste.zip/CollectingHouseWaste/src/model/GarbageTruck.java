package model;
public class GarbageTruck {
    private static final int MAX_TRUCK_CAPACITY = 10000; // Maximum capacity of the truck in tons
    private static final int LOADING_TIME_PER_POINT = 8; // Average time to load garbage at a point in minutes
    private static final int DUMP_TIME = 30; // Average time to go to and from the dump in minutes

    private int currentLoad;
    private int totalTime;

    public GarbageTruck() {
        currentLoad = 0;
        totalTime = 0;
    }

    public void loadGarbage(int garbageAmount) {
        currentLoad += garbageAmount;
        totalTime += LOADING_TIME_PER_POINT;

        if (currentLoad > MAX_TRUCK_CAPACITY) {
            currentLoad = 0;
            totalTime += DUMP_TIME - LOADING_TIME_PER_POINT;
        }
    }

    public void dumpGarbage() {
        if (currentLoad > 0) {
            totalTime += DUMP_TIME;
            currentLoad = 0;
        }
    }

    public int getTotalTime() {
        return totalTime;
    }
}