package main;

import controller.IncomeTaxController;
import model.IncomeTaxModel;
import view.IncomeTaxView;

public class Main {
    public static void main(String[] args) {
        IncomeTaxModel model = new IncomeTaxModel();
        IncomeTaxView view = new IncomeTaxView();
        IncomeTaxController controller = new IncomeTaxController(model, view);
        controller.calculateTax();
    }
}