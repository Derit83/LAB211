package controller;

import java.util.Scanner;
import model.IncomeTaxModel;
import view.IncomeTaxView;

public class IncomeTaxController {
    private IncomeTaxModel model;
    private IncomeTaxView view;
    private Scanner scanner;

    public IncomeTaxController(IncomeTaxModel model, IncomeTaxView view) {
        this.model = model;
        this.view = view;
        this.scanner = new Scanner(System.in);
    }

    public void calculateTax() {
        int income = view.getInput(scanner, "Enter your income: ");
        int numberOfChildren = view.getInput(scanner, "Enter the number of children: ");
        int[] childrenAges = view.getArrayInput(scanner, "Enter the ages of your children: ", numberOfChildren);
        int numberOfParents = view.getInput(scanner, "Enter the number of parents: ");

        int taxAmount = model.calculateTax(income, childrenAges, numberOfParents);
        view.displayResult("Your tax amount is: " + taxAmount);
    }
}