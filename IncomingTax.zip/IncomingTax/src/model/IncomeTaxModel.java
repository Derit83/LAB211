package model;

import java.util.Arrays;

public class IncomeTaxModel {
    private static final int MILLION = 1000000;
    private static final int MAX_CHILDREN_DEDUCTION = 2;
    private static final int CHILD_DEDUCTION_UNDER_18 = 4400000;
    private static final int CHILD_DEDUCTION_STUDYING = 6000000;
    private static final int PARENT_DEDUCTION = 4400000;
    private static final int TAX_THRESHOLD = 11000000;
    private static final int[] TAX_RATES = {5, 10, 20}; // Tax rates in percent

    public int calculateTax(int income, int[] childrenAges, int numberOfParents) {
        int deductions = calculateDeductions(income, childrenAges, numberOfParents);
        int taxableIncome = Math.max(0, income - deductions);
        int taxAmount = calculateTaxAmount(taxableIncome);
        
        System.out.println("Details of deductions:");
        System.out.println("Total income: " + income + " VND");
        System.out.println("Deductions: " + deductions + " VND");
        System.out.println("Taxable income: " + taxableIncome + " VND");
        System.out.println("Tax amount to be paid: " + taxAmount + " VND");

        return taxAmount;
    }

    private int calculateDeductions(int income, int[] childrenAges, int numberOfParents) {
        int selfDeduction = 11 * MILLION; // Deduction for self
        int childDeduction = calculateChildDeduction(childrenAges); // Deduction for supporting children
        int parentDeduction = calculateParentDeduction(numberOfParents); // Deduction for supporting parents
        return selfDeduction + childDeduction + parentDeduction;
    }

    private int calculateChildDeduction(int[] childrenAges) {
        int totalDeduction = 0;
        int numChildren = childrenAges.length;
        int[] sortedAges = Arrays.copyOf(childrenAges, numChildren);
        Arrays.sort(sortedAges);

        for (int i = numChildren - 1; i >= Math.max(0, numChildren - MAX_CHILDREN_DEDUCTION); i--) {
            int age = sortedAges[i];
            if (age <= 18) {
                totalDeduction += CHILD_DEDUCTION_UNDER_18;
            } else if (age <= 22) {
                totalDeduction += CHILD_DEDUCTION_STUDYING;
            }
        }
        return totalDeduction;
    }

    private int calculateParentDeduction(int numberOfParents) {
        return numberOfParents * PARENT_DEDUCTION;
    }

    private int calculateTaxAmount(int taxableIncome) {
        if (taxableIncome <= 0) {
            return 0;
        }

        int taxAmount = 0;
        int remainingIncome = taxableIncome;

        for (int i = 0; i < TAX_RATES.length; i++) {
            int currentRate = TAX_RATES[i];
            int upperLimit = (i + 1) * MILLION * 2;
            
            if (remainingIncome <= 0) {
                break;
            }
            
            if (remainingIncome <= upperLimit) {
                taxAmount += remainingIncome * currentRate / 100;
            } else {
                taxAmount += upperLimit * currentRate / 100;
            }

            remainingIncome -= upperLimit;
        }

        return taxAmount;
    }
}
