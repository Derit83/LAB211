package view;

import java.util.Scanner;

public class IncomeTaxView {
    public int getInput(Scanner scanner, String message) {
        System.out.print(message);
        return scanner.nextInt();
    }

    public int[] getArrayInput(Scanner scanner, String message, int size) {
        int[] array = new int[size];
        System.out.print(message);
        for (int i = 0; i < size; i++) {
            array[i] = scanner.nextInt();
        }
        return array;
    }

    public void displayResult(String message) {
        System.out.println(message);
    }
}