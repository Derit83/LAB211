package controller;

import model.DictionaryModel;
import view.DictionaryView;

public class DictionaryController {
    public DictionaryModel model;
    public DictionaryView view;

    public DictionaryController(DictionaryModel model, DictionaryView view) {
        this.model = model;
        this.view = view;
    }

    public void addWord(String eng, String vi) {
        model.addWord(eng, vi);
        view.displayMenu();
    }

    public void removeWord(String eng) {
        model.removeWord(eng);
        view.displayMenu();
    }

    public void translate(String eng) {
        String translation = model.translate(eng);
        view.displayTranslation(translation);
        view.displayMenu();
    }

    public void exitProgram() {
        System.exit(0);
    }
}