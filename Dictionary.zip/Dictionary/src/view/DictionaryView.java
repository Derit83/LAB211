package view;

import controller.DictionaryController;
import java.util.Scanner;

public class DictionaryView {
    public DictionaryController controller;
    public Scanner scanner;

    public DictionaryView(DictionaryController controller) {
        this.controller = controller;
        scanner = new Scanner(System.in);
    }

    public void displayMenu() {
        System.out.println("----- Simple English - Vietnamese Dictionary -----");
        System.out.println("1. Add word");
        System.out.println("2. Delete word");
        System.out.println("3. Search word");
        System.out.println("4. Exit");
        System.out.print("Select an option: ");
    }

    public void getInput() {
        int option = scanner.nextInt();
        scanner.nextLine();

        switch (option) {
            case 1:
                System.out.print("Enter English word: ");
                String engWord = scanner.nextLine();
                System.out.print("Enter Vietnamese translation: ");
                String viWord = scanner.nextLine();
                controller.addWord(engWord, viWord);
                break;
            case 2:
                System.out.print("Enter English word to delete: ");
                String wordToDelete = scanner.nextLine();
                controller.removeWord(wordToDelete);
                break;
            case 3:
                System.out.print("Enter English word to translate: ");
                String wordToTranslate = scanner.nextLine();
                controller.translate(wordToTranslate);
                break;
            case 4:
                controller.exitProgram();
                break;
            default:
                System.out.println("Invalid option. Please try again.");
                break;
        }
    }

    public void displayTranslation(String translation) {
        if (translation.isEmpty()) {
            System.out.println("Translation not found.");
        } else {
            System.out.println("Translation: " + translation);
        }
    }
}