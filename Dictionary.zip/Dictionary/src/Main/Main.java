package Main;

import controller.DictionaryController;
import model.DictionaryModel;
import view.DictionaryView;

public class Main {
    public static void main(String[] args) {
        String databaseFilePath = "dictionary.dat";
        DictionaryModel model = new DictionaryModel(databaseFilePath);
        DictionaryView view = new DictionaryView(new DictionaryController(model, null)); 
        view.controller.view = view; 
        view.displayMenu();
        while (true) {
            view.getInput();
        }
    }
}