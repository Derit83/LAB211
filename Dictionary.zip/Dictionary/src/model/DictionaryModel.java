package model;

import java.io.*;
import java.util.*;

public class DictionaryModel {
    public HashMap<String, String> dictionary;
    public String databaseFilePath;

    public DictionaryModel(String databaseFilePath) {
        this.databaseFilePath = databaseFilePath;
        dictionary = new HashMap<>();
        loadData();
    }

    public void addWord(String eng, String vi) {
        dictionary.put(eng, vi);
        updateDatabase();
    }

    public void removeWord(String eng) {
        if (dictionary.containsKey(eng)) {
            dictionary.remove(eng);
            updateDatabase();
        } else {
            System.out.println("Word not found in the dictionary.");
        }
    }

    public String translate(String eng) {
        return dictionary.getOrDefault(eng, "");
    }

    private void loadData() {
        try {
            File file = new File(databaseFilePath);
            if (file.exists()) {
                FileInputStream fis = new FileInputStream(file);
                ObjectInputStream ois = new ObjectInputStream(fis);
                dictionary = (HashMap<String, String>) ois.readObject();
                ois.close();
                fis.close();
            }
        } catch (IOException | ClassNotFoundException e) {
            e.printStackTrace();
        }
    }

    private void updateDatabase() {
        try {
            FileOutputStream fos = new FileOutputStream(databaseFilePath);
            ObjectOutputStream oos = new ObjectOutputStream(fos);
            oos.writeObject(dictionary);
            oos.close();
            fos.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}