package model;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import model.StudentComparator;
public class StudentModel {
    public List<Student> students;

    public StudentModel() {
        students = new ArrayList<>();
    }

    public void addStudent(String name, String classes, float mark) {
        Student student = new Student(name, classes, mark);
        students.add(student);
    }

    public void sortStudents() {
        Collections.sort(students, new StudentComparator());
    }

    public List<Student> getStudents() {
        return students;
    }
}