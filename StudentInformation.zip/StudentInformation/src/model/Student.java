package model;
public class Student {
    public String name;
    public float mark;
    public String classes;

    public Student(String name, String classes, float mark) {
        this.name = name;
        this.classes = classes;
        this.mark = mark;
    }

    public String getName() {
        return name;
    }

    public String getClasses() {
        return classes;
    }

    public float getMark() {
        return mark;
    }
}