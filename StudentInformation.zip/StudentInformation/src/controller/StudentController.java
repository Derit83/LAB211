package controller;
import java.util.Collections;
import java.util.List;
import java.util.ArrayList;
import java.util.Scanner;
import model.StudentModel;
import view.StudentView;

public class StudentController {
    public StudentModel model;
    public StudentView view;

    public StudentController(StudentModel model, StudentView view) {
        this.model = model;
        this.view = view;
    }

    public void run() {
        Scanner scanner = new Scanner(System.in);

        view.displayMessage("====== Collection Sort Program ======");
        boolean enterMoreStudents = true;

        while (enterMoreStudents) {
            view.displayMessage("Please input student information");

            String name = view.getInput("Name: ");
            String classes = view.getInput("Classes: ");
            float mark = view.getFloatInput("Mark: ");

            model.addStudent(name, classes, mark);

            String choice = view.getInput("Do you want to enter more student information? (Y/N): ");
            enterMoreStudents = choice.equalsIgnoreCase("Y");
        }

        model.sortStudents();
        view.displayStudents(model.getStudents());
    }
}