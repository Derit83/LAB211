package view;
import java.util.List;
import java.util.Scanner;
import model.Student;

public class StudentView {
    public void displayMessage(String message) {
        System.out.println(message);
    }

    public String getInput(String prompt) {
        Scanner scanner = new Scanner(System.in);
        System.out.print(prompt);
        return scanner.nextLine();
    }

    public float getFloatInput(String prompt) {
        Scanner scanner = new Scanner(System.in);
        System.out.print(prompt);
        while (!scanner.hasNextFloat()) {
            System.out.print("Invalid input. Please enter a valid number: ");
            scanner.next();
        }
        return scanner.nextFloat();
    }

    public void displayStudents(List<Student> students) {
        System.out.println("\n-------------Student Information-------------");
        int count = 1;
        for (Student student : students) {
            System.out.println("-------------Student " + count + "-------------");
            System.out.println("Name: " + student.getName());
            System.out.println("Classes: " + student.getClasses());
            System.out.println("Mark: " + student.getMark());
            count++;
        }
    }
}