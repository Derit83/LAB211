package view;


public enum SalaryStatus {
    INCREASE,
    DECREASE
}
