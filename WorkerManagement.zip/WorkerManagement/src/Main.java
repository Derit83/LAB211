
import view.WorkerView;


public class Main {
    public static void main(String[] args) {
        WorkerView view = new WorkerView();
        view.run();
    }
}
