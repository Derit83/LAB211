package CalculatorProgram;
import controller.CalculatorController;
public class CalculatorProgram {
    public static void main(String[] args) {
        CalculatorController calculatorController = new CalculatorController();
        calculatorController.runProgram();
    }
}