package Main;

import controller.ValidatorController;

public class Main {
    public static void main(String[] args) {
        ValidatorController controller = new ValidatorController();
        controller.run();
    }
}