package model;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.regex.Pattern;

public class ValidatorModel {
    private static final String PHONE_REGEX = "^[0-9]+$";
    private static final String EMAIL_REGEX = "^[\\w.-]+@[\\w.-]+\\.[a-zA-Z]{2,}$";
    private static final String DATE_FORMAT = "dd/MM/yyyy";

    public String checkPhone(String phone) {
    if (!Pattern.matches(PHONE_REGEX, phone)) {
        return "Phone number must be a number";
    } else if (phone.length() != 10) {
        return "Phone number must have 10 digits";
    }
    return "";
}

    public String checkDate(String date) {
        SimpleDateFormat dateFormat = new SimpleDateFormat(DATE_FORMAT);
        dateFormat.setLenient(false);
        try {
            dateFormat.parse(date);
        } catch (ParseException e) {
            return "Date must be in the format dd/MM/yyyy";
        }
        return "";
    }

    public String checkEmail(String email) {
        if (!Pattern.matches(EMAIL_REGEX, email)) {
            return "Email must be in correct format(abc@gmail.com)";
        }
        return "";
    }
}