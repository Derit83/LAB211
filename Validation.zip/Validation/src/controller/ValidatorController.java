package controller;

import model.ValidatorModel;
import view.ValidatorView;

public class ValidatorController {
    private ValidatorView view;
    private ValidatorModel model;

    public ValidatorController() {
        view = new ValidatorView();
        model = new ValidatorModel();
    }

    public void run() {
        view.displayMessage("====== Validate Program ======");

        String phone = view.getInput("Phone number: ");
        String phoneErrorMessage = model.checkPhone(phone);
        while (!phoneErrorMessage.isEmpty()) {
            view.displayMessage(phoneErrorMessage);
            phone = view.getInput("Phone number: ");
            phoneErrorMessage = model.checkPhone(phone);
        }

        String email = view.getInput("Email: ");
        String emailErrorMessage = model.checkEmail(email);
        while (!emailErrorMessage.isEmpty()) {
            view.displayMessage(emailErrorMessage);
            email = view.getInput("Email: ");
            emailErrorMessage = model.checkEmail(email);
        }

        String date = view.getInput("Date (dd/MM/yyyy): ");
        String dateErrorMessage = model.checkDate(date);
        while (!dateErrorMessage.isEmpty()) {
            view.displayMessage(dateErrorMessage);
            date = view.getInput("Date (dd/MM/yyyy): ");
            dateErrorMessage = model.checkDate(date);
        }

        view.displayMessage("All inputs are in the correct format. Exiting the program.");
    }
}